import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class NativeAdController extends GetxController {
  NativeAd? ad;
  final adLoaded = false.obs;
}
