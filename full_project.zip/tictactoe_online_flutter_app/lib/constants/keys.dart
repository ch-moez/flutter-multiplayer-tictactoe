enum Keys {
  user,
  isDarkTheme,
  token,
  selectedLanguage,
  isLoggedIn,
  receiveNotification,
}
