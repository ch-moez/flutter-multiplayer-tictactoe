class Constants {
  static const String appTitle = 'Remove Background';
  static const String website = 'https://www.cherif-moez.tounsi-tn.com/';
  static const String playStore =
      'https://play.google.com/console/u/0/developers/5362814431354960634/app-list';
  static const String appStore =
      'https://play.google.com/console/u/0/developers/5362814431354960634/app-list';

  static const String contactUs = 'https://wa.me/+33605907898';

  static const String termsAndConditions =
      'https://how-much-now.com/Terms_and_conditions.php';

  static const String aboutUs =
      'https://www.cherif-moez.tounsi-tn.com/about-us';

  static const String faq = 'https://www.cherif-moez.tounsi-tn.com/faq';

  static const String help = 'https://www.cherif-moez.tounsi-tn.com/help';

  static const String shareApp =
      'https://www.cherif-moez.tounsi-tn.com/share-app';

  static const String rateApp =
      'https://www.cherif-moez.tounsi-tn.com/rate-app';

  static const String privacyPolicy =
      'https://www.cherif-moez.tounsi-tn.com/privacy-policy';

  static const String developerEmail = 'devchmoez@gmail.com';
  static const String developerPhone = '+33605907898';

}
